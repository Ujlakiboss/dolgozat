﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace triatlon_doga
{
    internal class Class1
    {
        public string nev {  get; set; }
        public int szulev { get; set; }

        public int rajtszam { get; set; }
        public string nem {  get; set; }
        
        
        public string Kategoriak { get; set; }

        public int ido { get; set; }
        public DateTime uszasideje {  get; set; }
        public DateTime elsodepo {  get; set; }
        public DateTime canga {  get; set; }
        public DateTime masodikdepo {  get; set; }
        public DateTime futasideje { get; set; }


        public override string ToString()
        {
            return
               $"\tNev: {nev}\n" +
                $"\tszulev: {szulev}\n" +
                $"\trajtszam {rajtszam}\n" +
                $"\tNem: {nem}" +
                $"\tKategoriak: {Kategoriak}" +
                $"\tÚszás ideje: {uszasideje}" +
                $"\t Első depó: {elsodepo}" +
                $"\tCanga ideje: {canga}" +
                $"\t masodikdepo: {masodikdepo}" +
                $"\tFutas: {futasideje} ";




        }


        public Class1(string row)
        {
            var v = row.Split(';');
            nev = v[0];
            szulev = int.Parse(v[1]);
            rajtszam = int.Parse(v[2]);
            nem = v[3];
            Kategoriak = v[4];
            uszasideje = Convert.ToDateTime(v[5]);
            elsodepo = Convert.ToDateTime(v[6]);
            canga = Convert.ToDateTime(v[7]);
            masodikdepo = Convert.ToDateTime(v[8]);
            futasideje = Convert.ToDateTime(v[9]);

            



        }



    }
    
}
