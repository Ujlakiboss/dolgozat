﻿using System.Text;
using triatlon_doga;

List<Class1> Sportolok = [];

using StreamReader sr = new(
    path: @"..\..\..\src\forras.txt",
    encoding: Encoding.UTF8);
_ = sr.ReadLine();
while (!sr.EndOfStream) Sportolok.Add(new(sr.ReadLine()));


Console.WriteLine($"hany versenyző fejezte be: {Sportolok.Count}");

